# Tick

Bot completo de gerenciamento para comunidades no Discord, feito em discord.js v14 (Components V2 — tudo em containers).

## 1. Criar o bot no Discord

1. Acesse https://discord.com/developers/applications e crie uma aplicação chamada **Tick**.
2. Na aba **Bot**, clique em "Reset Token" e copie o token (isso vai no `.env`).
3. Ainda na aba Bot, ative estas 3 opções em **Privileged Gateway Intents**:
   - Presence Intent (opcional)
   - Server Members Intent (obrigatório)
   - Message Content Intent (obrigatório, usado pelos comandos com `!`)
4. Na aba **OAuth2 > URL Generator**, marque `bot` e `applications.commands`. Em permissões marque pelo menos: Administrator (mais simples) ou, manualmente: Gerenciar Canais, Gerenciar Cargos, Gerenciar Webhooks, Banir Membros, Expulsar Membros, Moderar Membros, Gerenciar Mensagens, Mover Membros, Criar Convite, Enviar Mensagens, Usar Comandos de Barra.
5. Use o link gerado para adicionar o bot ao seu servidor.

## 2. Configurar variáveis de ambiente

Copie `.env.example` para `.env` e preencha:

```
TOKEN=seu_token_aqui
CLIENT_ID=id_da_aplicacao_aqui
```

O `CLIENT_ID` fica na aba **General Information** da aplicação.

## 3. Instalar e rodar localmente

```bash
npm install
npm run deploy   # registra os comandos de barra (/) — rode 1x, ou use !sync dentro do servidor
npm start
```

## 4. Hospedar no Railway

1. Suba esse projeto para um repositório no GitHub.
2. Crie um novo projeto no Railway a partir do repositório.
3. Em **Variables**, adicione `TOKEN` e `CLIENT_ID`.
4. O Railway já detecta o `npm start` pelo `package.json`. Depois do primeiro deploy, rode `npm run deploy` localmente (ou use `!sync` no servidor, feito pelo dono) para registrar os comandos.

## 5. Hospedar no Replit

1. Crie um Repl importando esse projeto (ou fazendo upload da pasta).
2. Vá em **Secrets** (ícone de cadeado) e adicione `TOKEN` e `CLIENT_ID`.
3. No Shell do Replit rode `npm install` e depois `npm run deploy`.
4. Clique em Run (executa `npm start`). Para manter online 24/7 use o recurso de **Deployments** do Replit (o "Always On" antigo foi substituído por isso).

## 6. Como usar

- `/configurar call` — define o canal de voz gatilho; quem entrar nele ganha uma call própria, que some quando fica vazia.
- `/configurar logs` — escolhe, log por log, qual canal recebe cada tipo de aviso (cargos, fotos, mensagens, bans, warns, mute, kick, ticket, call, canais).
- `/configurar ticket` — abre um painel só seu (ephemeral) com botões para montar as opções de ticket, escolher botão ou menu, definir cargos de atendimento, escolher se abre tópico ou canal, e por fim publicar o painel público em um canal.
- `/configurar cargos` — controla quais cargos entram no `!historico` e quais são dados automaticamente (autorole).
- `!historico [@membro]` — mostra os cargos (do tipo configurado) que a pessoa já recebeu/perdeu, com data e hora.
- `/ban`, `/kick`, `/mute`, `/warn adicionar`, `/warn remover`, `/warn listar` (e as versões `!ban`, `!kick`, `!mute`, `!warn`, `!warnremove`) — todas pedem confirmação por botão antes de executar, e respeitam hierarquia de cargos.
- `!sync` — só o dono do servidor pode rodar; sincroniza os comandos de barra no servidor.
- `!comandos` — lista tudo que o bot faz.
- `/container criar` — monta um ou mais containers (texto + cor + botões com link), salva como template e envia por um webhook criado na hora, com nome e imagem personalizáveis.

## Observações técnicas

- O banco de dados é em arquivos JSON dentro de `data/` (criado automaticamente). Não precisa configurar nenhum banco externo.
- As sessões dos construtores (`/configurar ticket` e `/container criar`) ficam em memória — se o bot reiniciar no meio de uma configuração, é só rodar o comando de novo.
- Todas as mensagens do bot usam Components V2 (containers), então precisa do discord.js `^14.16.3` ou mais novo, já fixado no `package.json`.
